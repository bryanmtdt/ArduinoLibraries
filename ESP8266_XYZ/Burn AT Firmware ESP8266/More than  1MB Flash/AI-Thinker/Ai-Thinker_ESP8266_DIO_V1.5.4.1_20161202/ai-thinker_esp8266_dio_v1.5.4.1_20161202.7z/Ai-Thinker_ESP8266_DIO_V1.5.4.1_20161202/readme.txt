更新记录：
    更新 SDK 版本为 V1.5.4.1(39cb9a32)
    添加了 rf 修正扇区

如何下载：
    1. 该固件已合并 boot_v1.5.bin, user1.bin, esp_init_data_default.bin, blank.bin；
    2. 请使用ESP_DOWNLOAD_TOOL_V2.4 + 以上版本工具下载，下载地址为0x00000；
    3. 如果不知道如何配置Flash选项，请勾选"DoNotChgBin"，这样下载时会按照默认设置下载；
    4. 下载配置可参考 http://wiki.ai-thinker.com/doku.php/utils/esp_bin_download。
    
    更多信息请访问  http://www.ai-thinker.com/ 或 http://wiki.ai-thinker.com/
    有任何疑问请发送邮件至 support@aithinker.com
    
    安信可科技
    2016-12-02
===================================================================================
Change List：
    update sdk version to V1.5.4.1(39cb9a32)
    add rf cal sector

How to download:

    1. This firmware have already combined boot_v1.5.bin, user1.bin, esp_init_data_default.bin, blank.bin；
    2. Please select the firmware in ESP_DOWNLOAD_TOOL_V2.4 +, The address should write 0x00000;
    3. If you don't know how to config your download panel, please checked the "DoNotChgBin". That will be download the bin as default setting;
    4. Please refer to http://wiki.ai-thinker.com/doku.php/utils/esp_bin_download if you don't know how to download.
    
    More infomation please visit http://www.ai-thinker.com/ or http://wiki.ai-thinker.com/
    If you have any question, please send your mail to support@aithinker.com 
    
    Ai-Thinker
    2016-12-02